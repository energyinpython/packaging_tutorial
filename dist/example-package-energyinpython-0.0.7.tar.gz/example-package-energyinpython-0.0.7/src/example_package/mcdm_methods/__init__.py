from .spotis import SPOTIS
from . import mcdm_method