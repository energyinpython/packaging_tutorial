from .spotis import SPOTIS
from .de import DE_algorithm

from . import additions
from . import correlations
from . import mcdm_method
from . import normalizations
from . import weighting_methods